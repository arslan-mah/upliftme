import { Server } from "socket.io";
import mongoose from "mongoose";
import Session from "../models/session.model.js";

const MAX_CALL_DURATION = 15 * 60 * 1000; // 15 minutes in milliseconds

const SocketSetup = (server) => {
  const io = new Server(server, {
    cors: {
      origin: [`http://192.168.100.92:5173`],
      credentials: true,
      methods: ["GET", "POST"],
    },
  });

  const emailToSocketIdMap = new Map();
  const socketidToEmailMap = new Map();
  const activeCalls = new Map();
  const onlineUsers = {};

  io.on("connection", (socket) => {
    socket.emit("me", socket.id);

    const usersList = Object.values(onlineUsers);

    socket.emit("usersList", usersList);

    socket.on("registerUser", (username) => {
      if (!username) return;

      onlineUsers[socket.id] = {
        username: username,
        socketId: socket.id,
      };

      io.emit("usersList", Object.values(onlineUsers));
    });

    socket.on("room:join", (data) => {
      const { email, room } = data;
      emailToSocketIdMap.set(email, socket.id);
      socketidToEmailMap.set(socket.id, email);
      io.to(room).emit("user:joined", { email, id: socket.id });
      socket.join(room);
      io.to(socket.id).emit("room:join", data);
    });

    socket.on("user:call", ({ to, offer }) => {
      io.to(to).emit("incomming:call", { from: socket.id, offer });

      const callId = `${socket.id}-${to}`;
      activeCalls.set(
        callId,
        setTimeout(() => {
          io.to(socket.id).emit("call:end");
          io.to(to).emit("call:end");
          activeCalls.delete(callId);
        }, MAX_CALL_DURATION)
      );
    });

    socket.on("call:accepted", ({ to, ans }) => {
      io.to(to).emit("call:accepted", { from: socket.id, ans });
    });

    socket.on("ice:candidate", ({ to, candidate }) => {
      io.to(to).emit("ice:candidate", { from: socket.id, candidate });
    });

    socket.on("call:end", ({ to }) => {
      io.to(to).emit("call:end");

      const callId1 = `${socket.id}-${to}`;
      const callId2 = `${to}-${socket.id}`;

      if (activeCalls.has(callId1)) {
        clearTimeout(activeCalls.get(callId1));
        activeCalls.delete(callId1);
      }

      if (activeCalls.has(callId2)) {
        clearTimeout(activeCalls.get(callId2));
        activeCalls.delete(callId2);
      }
    });

    socket.on("peer:nego:needed", ({ to, offer }) => {
      io.to(to).emit("peer:nego:needed", { from: socket.id, offer });
    });

    socket.on("peer:nego:done", ({ to, ans }) => {
      io.to(to).emit("peer:nego:final", { from: socket.id, ans });
    });

    socket.on("disconnect", () => {
      const email = socketidToEmailMap.get(socket.id);
      if (email) {
        emailToSocketIdMap.delete(email);
        socketidToEmailMap.delete(socket.id);
      }

      if (onlineUsers[socket.id]) {
        delete onlineUsers[socket.id];

        io.emit("usersList", Object.values(onlineUsers));
      }

      for (const [callId, timeout] of activeCalls.entries()) {
        if (callId.includes(socket.id)) {
          const [caller, receiver] = callId.split("-");
          const otherParty = caller === socket.id ? receiver : caller;

          io.to(otherParty).emit("call:end");
          clearTimeout(timeout);
          activeCalls.delete(callId);
        }
      }
    });
  });

  return io;
};

export default SocketSetup;
